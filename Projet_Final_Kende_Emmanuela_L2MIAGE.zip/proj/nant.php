
<!DOCTYPE html>
<html>
<head>
	<title>Nantflix</title>
	<link rel="stylesheet" type="text/css" href="Design.css">
</head>
<body>
	
	<h1>NanTflix</h1><br>
	<a id="ajout"href="insert_serie.php"> ajouter des series</a>
	<a id="conect" href="connexion.php">S'identifier</a>
	<div class ="animation"><h3> Profitez de films, séries et bien d'autre en illimité sur Nantflix,</h3></div>
	<!-- ajouter une galerie d'image a cet emplacement-->
	<div class= "galerie">
		<a href="image/img1.png"><img src="image/img1.png"></a>
		<a href="image/img2.jpg"><img src="image/img2.jpg"></a>
		<a href="image/img3.jpg"><img src="image/img3.jpg"></a>
		<a href="image/img4.jpg"><img src="image/img4.jpg"></a>
	</div>
	<p id="a">Pas encore inscrit? </p><br>
	<p id="b">Inscrivez vous pour profiter des films et serie en exclusivité sur Nantflix</p>
	<a id= "ins" href="inscrip_utilisateur.php">S'inscrire</a>
	<!--on fait un boutton qui nous permet de remonter la page-->
	<div id="boutton">
<a href="#top"><img src="to_top.png"/></a>
</div>
</body>
</html>


